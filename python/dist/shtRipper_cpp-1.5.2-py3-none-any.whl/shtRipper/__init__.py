from shtRipper import shtRipper_entry

ripper = shtRipper_entry.Ripper()

# require python >= 3.5 for ctypes compiler match
# c++ toolchain: Visual Studio 2019 (pro). Version 16. Arc: x86_amd64. CMake: bundled
# c++ toolchain: Visual Studio 2019 (pro). Version 16. Arc: x86. CMake: bundled